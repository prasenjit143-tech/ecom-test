function Gallery()
{
    return(
        <h1>Gallery</h1>
    )
}
export default Gallery;