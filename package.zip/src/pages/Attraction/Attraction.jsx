function Attraction()
{
    return(
        <h1>Attraction</h1>
    )
}
export default Attraction;